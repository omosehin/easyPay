import React from 'react'
import Layout from './Hoc/Layout'
import jwt_decode from 'jwt-decode'
import setAuthToken from './util/setAuthToken'
import { setCurrentUser } from './actions/auth'
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { Provider } from 'react-redux';
import store from './store'
import SideDrawer from './components/sidebar/SideDrawer'

import CardGrid from '../src/components/Home'
import AllUsers from './components/all-users'
import Transactions from '../src/components/transactions'
import ReconsilePayment from '../src/components/reconsilepayment'
import Merchant from '../src/components/merchant'
import SendMail from '../src/components/sendmaill'
import Admin from '../src/components/admin'
import Login from './components/login'
import { Row, Col } from 'reactstrap';


if (localStorage.jwtToken) {
    setAuthToken(localStorage.jwtToken);

    const decoded = jwt_decode(localStorage.jwt_decode)

    store.dispatch(setCurrentUser(decoded));
}



const Routes = (props) => {
    return (
        <div style={{ marginLeft: '0px' }}>
            {/* <Provider store={store}>

                <Router>
                    <Route path path="/login" component={Login} />


                    <Layout>
                        <Row style={{ background: '#141e2f' }}>

                            <Col xs='3'>
                                <SideDrawer />
                            </Col>

                            <Col xs='9' style={{ marginTop: '100px', marginLeft: '-100px' }}>
                                <Route exact path="/" component={CardGrid} />
                                <Route path="/dashboard" component={CardGrid} />
                                <Route path="/all-users" component={AllUsers} />
                                <Route path="/transactions" component={Transactions} />
                                <Route path="/reconcile-payment" component={ReconsilePayment} />
                                <Route path="/merchants" component={Merchant} />
                                <Route path="/send-email" component={SendMail} />
                                <Route path="/admin-users" component={Admin} />
                            </Col>
                        </Row>

                    </Layout>
                </Router>
            </Provider> */}


        </div>
    )
}
export default Routes;
