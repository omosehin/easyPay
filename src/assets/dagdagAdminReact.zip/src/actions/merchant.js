import axios from 'axios';
import { FETCH_ALL_MERCHANTS, GET_ERROR, ADD_MERCHANT, LOADING} from "./constants";

const BASE_URL='http://localhost:17000'

export const fetchAllMerchant = () => dispatch => {
    dispatch(fetchAllMerchantLoading());

    axios.get("/api/merchant/getAllMerchants")
        .then(res => {
            dispatch({
                type: FETCH_ALL_MERCHANTS,
                payload: res.data.merchant
            })
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response.data
            })
        );
};


export const addMarchant = merchantName => dispatch => {
   // dispatch(clearErrors());

    axios
        .post("/api/merchant/create", merchantName)
        .then(res =>
            dispatch({
                type: ADD_MERCHANT,
                payload: res.data
            })
        )
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response
            })
        );
};



export const fetchAllMerchantLoading = () => {
    return {
        type: LOADING
    };
};

