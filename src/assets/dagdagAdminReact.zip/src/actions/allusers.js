import axios from 'axios';
import { FETCH_ALL_USERS, FETCH_ALL_ADMIN, GET_USER, GET_ERROR, DASHBOARD_LOADING} from "./constants";
import {BASE_URL} from './BaseUrl'

export const fetchAllUsers = () => dispatch => {
    dispatch(dashBoardLoading());

    axios.get(`${BASE_URL}/api/users/getAllUsers`)
        .then(res => {
            dispatch({
                type: FETCH_ALL_USERS,
                payload: res.data.users
            })
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response
            })
        );
};
export const fetchAllAdmin = () => dispatch => {
    dispatch(dashBoardLoading());

    axios.get(`${BASE_URL}/api/users/getAllAdmin`)
        .then(res => {
            dispatch({
                type: FETCH_ALL_ADMIN,
                payload: res.data.admins
            })
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response.data
            })
        );
};
export const getUserViaId = (userId) => dispatch => {
    dispatch(dashBoardLoading());

    axios.get(`${BASE_URL}/api/users/getUserViaId/${userId}`)
        .then(res => {
            dispatch({
                type: GET_USER,
                payload: res.data.user
            })
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response
            })
        );
};


export const dashBoardLoading = () => {
    return {
        type: DASHBOARD_LOADING
    };
};

