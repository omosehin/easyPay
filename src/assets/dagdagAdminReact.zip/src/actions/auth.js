import axios from "axios";
import { GET_ERROR, SET_CURRENT_USER } from "./constants";
import setAuthToken from '../util/setAuthToken'
import jwt_decode from 'jwt-decode';
import {BASE_URL} from './BaseUrl'

export const loginUser = (userData) => dispatch => {

    axios.post(`${BASE_URL}/api/users/adminlogin`, userData)
        .then(res => {

            const {token} = res.data

            localStorage.setItem('jwtToken', token);

            setAuthToken(token)
            dispatch(setCurrentUser())

        })
        .catch(err => {
            dispatch({
            type: GET_ERROR,
            payload: (err && err.response && err.response.data) || 'network error'
        })})

} 

export const setCurrentUser =(decoded) =>{
    return{
        type: SET_CURRENT_USER,
        payload: decoded
    }
}

export const logout =() => dispatch =>{

    localStorage.removeItem('jwtToken');

    setAuthToken('false')

    dispatch(setCurrentUser({}))

}