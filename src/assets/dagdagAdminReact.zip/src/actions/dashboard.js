import axios from 'axios';
import { FETCH_LAST_THREE, GET_MONTH, GET_TOTAL_USERS_COUNT, GET_TOTAL_USER_COUNT, GET_ERROR, DASHBOARD_LOADING} from "./constants";
import {BASE_URL} from './BaseUrl'

export const getLastThreeTransactions = () => dispatch => {
    dispatch(dashBoardLoading());

    axios.get(`${BASE_URL}/api/transaction/getLastThree`)
        .then(res => {
            dispatch({
                type: FETCH_LAST_THREE,
                payload: res.data.trans
            })
           // console.log('-------'+JSON.stringify(res.data))
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response
            })
        );
};

export const getAllUsers = () => dispatch => {
    dispatch(dashBoardLoading());

    axios.get(`${BASE_URL}/api/users/getAllUsersCount`)
        .then(res => {
            dispatch({
                type: GET_TOTAL_USERS_COUNT,
                payload: res.data.users
            })
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response
            })
        );
};

export const getMonthName = () => dispatch => {
    dispatch(dashBoardLoading());

    axios.get(`${BASE_URL}/api/admin/getMonthName`)
        .then(res => {
            dispatch({
                type: GET_MONTH,
                payload: res.data.monthName
            })
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response.data
            })
        );
};


export const dashBoardLoading = () => {
    return {
        type: DASHBOARD_LOADING
    };
};

