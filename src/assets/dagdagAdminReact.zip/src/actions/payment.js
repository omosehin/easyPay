 import axios from 'axios'
 import {BASE_URL} from './BaseUrl'
 import * as actionTypes from './constants'

 const merchantInitIdentityPayment=()=>{
     return{
        type:actionTypes.MERCHANT_INIT_IDENTITY_PAYMENT  
     }
 }
 
 const merchantSuccessIdentityPayment=(data)=>{
     return{
        type:actionTypes.MERCHANT_SUCCESS_IDENTITY_PAYMENT,
        payload:data
     }
 }

 const merchantErrorIdentityPayment = (data)=>{
     return{
        type:actionTypes.MERCHANT_ERROR_IDENTITY_PAYMENT
     }
 }

export const merchantData=data=>{
    let passStoken = localStorage.getItem('jwtToken')
    return function (dispatch){
        dispatch(merchantInitIdentityPayment());
        axios.post(BASE_URL +'/api/merchant/create' + passStoken,data)
        .then(res=>{
            dispatch(merchantSuccessIdentityPayment(res&&res.data))
        })
        .catch(err=>{
                    console.log(typeof err.response)
            dispatch(merchantErrorIdentityPayment(err))
        })
    }
}

