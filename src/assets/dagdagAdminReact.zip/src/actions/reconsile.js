import axios from 'axios';
import { FETCH_ALL_USERS_UNRECONSILED, GET_ERROR, LOADING} from "./constants";
import {BASE_URL} from './BaseUrl'

export const fetchAllUnReconciled = () => dispatch => {
    dispatch(transactionLoading());

    axios.get(`${BASE_URL}/api/transaction/unreconsiled`)
        .then(res => {
            dispatch({
                type: FETCH_ALL_USERS_UNRECONSILED,
                payload: res.data.reconcile
            })
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response.data
            })
        );
};


export const transactionLoading = () => {
    return {
        type: LOADING
    };
};

