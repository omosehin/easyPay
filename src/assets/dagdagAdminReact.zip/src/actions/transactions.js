import axios from 'axios';
import { FETCH_ALL_USERS_TRANSACTIONS, GET_ERROR, LOADING} from "./constants";
import {BASE_URL} from './BaseUrl'

export const fetchAllTransactions = () => dispatch => {
    dispatch(transactionLoading());

    axios.get(`${BASE_URL}/api/transaction/fetchAllTransactions`)
        .then(res => {
            console.log(res)
            dispatch({
                type: FETCH_ALL_USERS_TRANSACTIONS,
                payload: res.data.transactions
            })
        })
        .catch(err =>
            dispatch({
                type: GET_ERROR,
                payload: err.response.data
            })
        );
};


export const transactionLoading = () => {
    return {
        type: LOADING
    };
};

