import React, { Component } from "react";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import Avatar from '@material-ui/core/Avatar'
import { dagdag } from './dagdag.svg'
// import { logOutUser } from "../../actions/authActions";

class Navbar extends Component {
  onLogoutClick(e) {
    e.preventDefault();
    // this.props.logOutUser();
  }
  render() {
    const { isAuthenticated, user } = this.props.auth;

    return (

      <div className="container" style={{
        width: '100%', zIndex: '10',
        position: "relative",
        flexDirection: "row",
        height: "60px",
        padding: "0", backgroundColor:
          "#182538", boxShadow: '0 1px 10px 1px rgba(115, 108, 203, .1)',
        webkitBoxDirection: 'normal',
        webkitBoxOrient: 'horizontal',
        webkitFlexDirection: 'row',
        msFlexDirection: 'row'
      }} >
        <div style={{background:{dagdag}}}/>
          <img src={'/'+dagdag} style={{ width: '100px', height:'100px' }} />
          <div>jdj</div>
 
        </div>
    );
  }
}

Navbar.propTypes = {
  // logOutUser: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired
};


const mapStateToProps = state => ({
  auth: state.auth
});
export default connect(
  mapStateToProps,
  {}
)(Navbar);
