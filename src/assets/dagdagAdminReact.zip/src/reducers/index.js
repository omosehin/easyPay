import {combineReducers} from 'redux';
import dashboardReducer from './dashboard';
import allUserReducer from './allusers';
import allTransactionsReducer from './transactions';
import reconciledReducer from './reconsile';
import merchantReducer from './merchant';
import authReducer from './auth'
import errorReducer from './error'
import {PaymentInitReducer} from './payment'
// import profileReducer from './profileReducer';
// import postReducer from './postReducer';

export default combineReducers({
    dashboard: dashboardReducer,
    allusers: allUserReducer, 
    transactions: allTransactionsReducer, 
    reconcile: reconciledReducer, 
    merchant: merchantReducer, 
    auth:authReducer,
    error:errorReducer,
    PaymentInitReducer
    // profile: profileReducer, 
    // post: postReducer 
});