import * as actionTypes from '../actions/constants'
const INITIAL_STATE ={
    data:[],
    merchantInitIdentityPayment:false

}
export const PaymentInitReducer=(state=INITIAL_STATE,action)=>{
    switch (action.type) {
        case actionTypes.MERCHANT_INIT_IDENTITY_PAYMENT:
            return{
                ...state,
                merchantInitIdentityPayment:true
            }
        case actionTypes.MERCHANT_SUCCESS_IDENTITY_PAYMENT:
            return{
                ...state,
                merchantInitIdentityPayment:false,
                data:action.payload
            }
        case actionTypes.MERCHANT_ERROR_IDENTITY_PAYMENT:
            return{
                ...state,
                merchantInitIdentityPayment:false,
                data:action.payload
            }
    
        default:
            return state;

    }

}