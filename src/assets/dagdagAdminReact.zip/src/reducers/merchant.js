import { FETCH_ALL_MERCHANTS,ADD_MERCHANT, LOADING } from '../actions/constants';

const initialState = {
    merchant: [],
    loading: false
};

export default function (state = initialState, action) {
    switch (action.type) {

        case LOADING:
            return {
                ...state,
                loading: true
            };


        case FETCH_ALL_MERCHANTS:
            return {
                ...state,
                merchant: action.payload,
                loading: false
            };

        case ADD_MERCHANT:
            return {
                ...state,
                merchant: [action.payload, ...state.merchant]
            };
        default:
            return state;
    }
}
