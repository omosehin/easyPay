import { FETCH_LAST_THREE, GET_MONTH, GET_TOTAL_USERS_COUNT, DASHBOARD_LOADING, LOADING } from '../actions/constants';
// import isEmpty from '../validation/is-empty';

const initialState = {
    totalUser: 0,
    month: '',
    lastThreeTranzact: [],
    loading: false
};

export default function (state = initialState, action) {
    switch (action.type) {

        case DASHBOARD_LOADING:
            return {
                ...state,
                loading: true
            };

        case FETCH_LAST_THREE:
            return {
                ...state,
                lastThreeTranzact: action.payload,
                loading: false
            };

        case LOADING:
            return {
                ...state,
                loading: true
            };

        case GET_MONTH:
            return {
                ...state,
                month: action.payload,
                loading: false
            };
        case GET_TOTAL_USERS_COUNT:
            return {
                ...state,
                totalUser: action.payload,
                loading: false
            };
        default:
            return state;
    }
}
