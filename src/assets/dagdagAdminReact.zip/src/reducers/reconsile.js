import { FETCH_ALL_USERS_UNRECONSILED, LOADING } from '../actions/constants';

const initialState = {
    reconcile: [],
    loading: false
};

export default function (state = initialState, action) {
    switch (action.type) {

        case LOADING:
            return {
                ...state,
                loading: true
            };

        case FETCH_ALL_USERS_UNRECONSILED:
            return {
                ...state,
                reconcile: action.payload,
                loading: false
            };
        default:
            return state;
    }
}
