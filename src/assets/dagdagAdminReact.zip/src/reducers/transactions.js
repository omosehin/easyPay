import { FETCH_ALL_USERS_TRANSACTIONS, LOADING } from '../actions/constants';

const initialState = {
    transactions: [],
    loading: false
};

export default function(state = initialState, action) {
    switch (action.type) {

        case LOADING:
            return {
                ...state,
                loading: true
            };

        case FETCH_ALL_USERS_TRANSACTIONS:
            return {
                ...state,
                transactions: action.payload,
                loading: false
            };
        default:
            return state;
    }
}
