import { SET_CURRENT_USER, GET_ERROR } from '../actions/constants'
const initialState ={
    isAuthenticated: false,
    user:{}
}

export default function(state=initialState, action){
    switch(action.type){
        case SET_CURRENT_USER:
            return{
                ...state,
                isAuthenticated: true,
                user: action.payload
            }
        case GET_ERROR:
            return{
                ...state,
                isAuthenticated:false,
                user:action.paylaod
            }
            
        default:
            return state
    }
}