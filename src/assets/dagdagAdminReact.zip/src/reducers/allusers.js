import { FETCH_ALL_USERS, GET_USER, FETCH_ALL_ADMIN, LOADING } from '../actions/constants';

const initialState = {
    allusers: [],
    user:{},
    alladmin:[],
    loading: false
};

export default function (state = initialState, action) {
    switch (action.type) {

        case LOADING:
            return {
                ...state,
                loading: true
            };

        case FETCH_ALL_USERS:
            return {
                ...state,
                allusers: action.payload,
                loading: false
            };
        case FETCH_ALL_ADMIN:
            return {
                ...state,
                alladmin: action.payload,
                loading: false
            };
        case GET_USER:
            return {
                ...state,
                user: action.payload,
                loading: false
            };
        default:
            return state;
    }
}
