import React, { Component } from 'react'
import {withRouter} from 'react-router-dom'
import AppBar from '@material-ui/core/AppBar'
import {Dagdag} from '../../components/logo/icon'
import jwt_decode from 'jwt-decode';

const styleButton ={
    marginright:'30px'
}
 class Header extends Component {
    constructor(props) {
        super(props)
    }
    goToHome=()=>{
        const {history} =this.props
        history.push("/login")
        localStorage.removeItem('jwtToken')
        window.location.reload()
      
      }
    render() {
        let user= localStorage.getItem('jwtToken');  
              
        return (
            <AppBar style={{ backgroundColor: '#182538' }}  >
                            <div className="header_logo d-flex">
                                <div><Dagdag></Dagdag></div>
                                <div style={{flex:'1'}}></div>                         
                                {user && <button className ='logoutButton' onClick={this.goToHome}>LOG OUT</button>}
                            </div>

                </AppBar>
        )
    }
}

export default withRouter(Header)