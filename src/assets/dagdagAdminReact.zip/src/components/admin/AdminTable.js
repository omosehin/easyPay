import React, { Component } from 'react'
import { Table, Card, CardBody } from 'reactstrap';


export default class AdminTable extends Component {
    render() {
        const { alladmin } = this.props
        return (
            <Card style={{ background: 'rgb(24, 37, 56)', padding: '20px', marginTop: '0px' }}>
                <CardBody style={{ background: 'rgb(24, 37, 56)' }}>
                    <Table style={{ marginTop: '100px', padding: '50px' }}>
                        <thead style={{ color: 'white' }}>
                            <tr style={{ padding: '30px' }}>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        {alladmin.map(user =>

                            <tbody style={{ color: '#6c757d' }}>
                                <tr>
                                    <td>{user.first_name}</td>
                                    <td>{user.family_name}</td>
                                    <td>{user.isSuperAdmin === true ? <p>Super Admin</p> : <p></p>}{user.isSubAdmin === true ? <p>Sub Admin</p> : <p></p>}</td>
                                    <td>...</td>
                                </tr>

                            </tbody>
                        )}
                    </Table>

                </CardBody>
            </Card>
        );
    }
}
