import React, { Component } from 'react'
import { Card, CardBody, Form, FormGroup, Label, Input, Button } from 'reactstrap'

export default class AddAdminUser extends Component {
  render() {
    return (
      <div>
        <h1>Add User</h1>
        <Card style={{ background: 'rgb(24, 37, 56)'}}>
          <CardBody style={{ background: 'rgb(24, 37, 56)', width:'800px' }}>
            <Form>
              <FormGroup>
                <Label style={{ color: 'white' }}>First Name</Label>
                <Input typ="text" />
              </FormGroup>
            </Form>


            <Form>
              <FormGroup>
                <Label style={{ color: 'white' }}>Family Name</Label>
                <Input typ="text" />
              </FormGroup>
            </Form>

            <Form>
              <FormGroup>
                <Label style={{ color: 'white' }}>Email</Label>
                <Input typ="text" />
              </FormGroup>
            </Form>

            <Form>
              <FormGroup>
                <Label className="mylabel">Select Admin Role</Label>
                <select name="adminrole" className="form-control">
                  <option value="super">Super Admin</option>
                  <option value="subadmin">Sub Admin</option>
                </select>
              </FormGroup>
            </Form>


            <Form>
              <FormGroup>
                <Label style={{ color: 'white' }}>Password</Label>
                <Input type="password" />
              </FormGroup>
            </Form>

            <Form>
              <FormGroup>
                <Label style={{ color: 'white' }}>Confirm Password</Label>
                <Input type="password" />
              </FormGroup>
            </Form>

            <Form>
              <Button color="success">Add Admin</Button>
            </Form>

          </CardBody>
        </Card>
      </div>
    )
  }
}
