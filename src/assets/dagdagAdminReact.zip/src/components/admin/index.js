import React, { Component } from 'react'
import { connect } from 'react-redux'
import AdminTable from './AdminTable'
import { Button } from 'reactstrap'
import AddAdminUser from './AddAdminUser'
import { fetchAllAdmin } from '../../actions/allusers'


class index extends Component {
    state = {
        isNewAdmin: false
    }

    componentDidMount() {
        this.props.fetchAllAdmin()
    }
    render() {
        const { alladmin } = this.props.allusers
        console.log('Fetch all admin: ' + alladmin)
        return (
            <div style={{ marginTop: '-50px' }} >


                {!(this.state.isNewAdmin) ?
                    <div>

                        <div style={{ position: 'fixed', zIndex: '100', marginBottom: '300px', background: 'rgb(24, 37, 56)', width:'73.4%' }}>
                            <h4 style={{ fontSize: '1.5rem', color: 'white', marginTop: '50px' }}>All Admin  <small style={{ fontSize: '14px' }}>List of All Admins</small></h4>
                            <Button color="success"
                                style={{ margin: '10px' }}
                                onClick={() => this.setState({ isNewAdmin: true })}>New Admin</Button>{' '}
                        </div>


                        <AdminTable alladmin={alladmin} />
                    </div> :
                    <AddAdminUser />}
            </div>
        )
    }
}
const mapStateToProps = state => ({
    allusers: state.allusers
})
export default connect(mapStateToProps, { fetchAllAdmin })(index);

