import React, { Component } from 'react'
import SendMail from './SendMail'

export default class index extends Component {
  render() {
    return (
        <SendMail/>
    )
  }
}
