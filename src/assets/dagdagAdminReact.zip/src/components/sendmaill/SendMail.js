import React, { Component } from 'react'
import {Card, CardBody, Form, FormGroup, Label, Input} from 'reactstrap'
export default class SendMail extends Component {
  render() {
    return (
      <div>
        <h1>Send Mail</h1>

        <Card>
            <CardBody>
                <Form>
                    <FormGroup>
                            <Label for="exampleEmail">Subject</Label>
                            <Input type="text" name="name" id="merchantname" placeholder="Subject..." />
                            <Label for="exampleEmail">Subject</Label>
                            <Input type="textarea" name="name" id="merchantname" placeholder="Subject..." />

                    </FormGroup>
                </Form>
            </CardBody>
        </Card>
      </div>
    )
  }
}
