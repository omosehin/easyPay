import React from 'react';
import { Table } from 'reactstrap';
import AllUSerFeed from './AllUserFeed'

export default class AllUsers extends React.Component {
    render() {
        const users = this.props.allusers
        console.log('/////////' + JSON.stringify(users))
        return (
            
                users || users ===undefined ?<p style={{marginTop:'100px',marginLeft:'300px',color:'white'}}>Error </p>:
            
            <div>
                <h4 style={{ fontSize: '1.5rem', color: 'white' }}>All Users  <small style={{ fontSize: '14px' }}>List of All Users</small></h4>


                <Table style={{ marginTop: '30px', padding: '50px', background: 'rgb(24, 37, 56)' }}>
                    {users.map(user =>

                        <div>
                            <thead style={{ color: 'white' }}>
                                <tr>
                                    <th>#</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Nos of Transactions</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody style={{ color: '#6c757d' }}>
                                <tr>
                                    <td >1</td>
                                    {/* <td>{user.first_name}</td> */}
                                    {/* <td>{user.family_name}</td> */}
                                    <td>@mdo</td>
                                    <td>@mdo</td>
                                    <td>@mdo</td>
                                    <td>...</td>
                                </tr>

                            </tbody>
                        </div>
                    )} 
                </Table>
            </div>
        );
    }
}