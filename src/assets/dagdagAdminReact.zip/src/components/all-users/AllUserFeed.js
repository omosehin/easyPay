import React from 'react';
import { Table } from 'reactstrap';
import AllUsers from './AllUsers';

class AllUserFeed extends React.Component {
    render() {

        const { users } = this.props;
        // return allUsers.map(user => <AllUsers key={user._id} user={user} />);


        return (
            <div>
                {users.map(user =>

                    <div>
                        <thead style={{ color: 'white' }}>
                            <tr>
                                <th>#</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Nos of Transactions</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody style={{ color: '#6c757d' }}>
                            <tr>
                                <td >1</td>
                                <td>{user.first_name}</td>
                                <td>{user.family_name}</td>
                                <td>@mdo</td>
                                <td>@mdo</td>
                                <td>@mdo</td>
                                <td>...</td>
                            </tr>

                        </tbody>
                    </div>
                )}
            </div>
        
        )

    }
}
export default AllUserFeed;