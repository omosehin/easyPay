import React, { Component } from 'react';
import AllUserFeed from './AllUserFeed'
import AllUsers from './AllUsers'
import { connect } from 'react-redux';
import {
    Table,
    Card, Button, CardImg, CardTitle, CardText, CardColumns,
    CardSubtitle, CardBody, UncontrolledPopover, PopoverHeader, PopoverBody, Popover,
    ModalHeader, Modal, ModalFooter, ModalBody
} from 'reactstrap';
import Popup from 'reactjs-popup'

import { fetchAllUsers, getUserViaId } from '../../actions/allusers'



class index extends Component {

    constructor(props) {
        super(props);
        this.state = {
            modal: false
        };

        this.toggle = this.toggle.bind(this);
    }

    toggle(pid) {
        this.setState(prevState => ({
            modal: !prevState.modal
        }));
        this.props.getUserViaId(pid)

    }


    componentDidMount() {
        this.props.fetchAllUsers()
    }

    myFunction = () => {
        var popup = document.getElementById("myPopup");
        popup.classList.toggle("show");
    }
    render() {
        const { allusers,user } = this.props.allusers        
        return (
            <div>
                {
                    !allusers.length > 0 ? <p>No user(s)</p> :
                        <div>
                            <h4 style={{ fontSize: '1.5rem', color: 'white' }}>All Users  <small style={{ fontSize: '14px' }}>List of All Users</small></h4>
                            <Card style={{ background: 'rgb(24, 37, 56)', padding: '20px', marginTop: '20px' }}>
                                <CardBody style={{ background: 'rgb(24, 37, 56)' }}>
                                    <Table style={{ marginTop: '30px', padding: '50px', borderBottom:'green' }}>
                                        <thead style={{ color: 'white' }}>
                                            <tr style={{ padding: '30px' }}>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Email</th>
                                                <th>Phone </th>
                                                <th>Nos of Transactions</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        {allusers.map(user =>

                                            <tbody style={{ color: '#6c757d' }}>
                                                <tr style={{
                                                    color: 'white',
                                                      borderTop:' 1px solid #dee2e6',
                                                    borderBottom: ' 1px solid #dee2e6'}}>
                                                    <td>{user.first_name}</td>
                                                    <td>{user.family_name}</td>
                                                    <td>{user.email}</td>
                                                    <td>{user.mobile_no}</td>
                                                    <td>{user.no_of_transaction}</td>
                                                    <td>
                                                        <div >
                                                            <Popup
                                                                trigger={<button className=""> ... </button>}
                                                                position="top center"
                                                                style={{ color: 'red' }}
                                                                closeOnDocumentClick >
                                                                <div closeOnDocumentClick
                                                                    style={{
                                                                        width: '20px',
                                                                        background: 'rgb(69, 79, 99)',
                                                                        border: 'none',
                                                                        minWidth: '100px',
                                                                        fontSize: '11px',
                                                                        position: 'absolute',
                                                                        willChange: 'transform',
                                                                        top: '0px',
                                                                        left: '0px',
                                                                    }}>
                                                                    <button className="button" onClick={this.toggle.bind(this,user._id)} style={{ margin: '5px', width: '80px' }}> View </button>
                                                                    <span />
                                                                    <button className="button" style={{ margin: '5px', width: '80px' }}> 1° Verify </button>
                                                                    <button className="button" style={{ margin: '5px', width: '80px' }}> 2° Verify </button>
                                                                    <button className="button" style={{ margin: '5px', width: '80px' }}> 3° Verify </button>
                                                                </div>
                                                            </Popup>
                                                        </div>
                                                    </td>
                                                </tr>

                                            </tbody>
                                        )}
                                    </Table>

                                </CardBody>
                            </Card>
                        </div>

                }

                <div>
                    <div> 
                        <Modal isOpen={this.state.modal} 
                        toggle={this.toggle} 
                        className={this.props.className}
                            >
                            <ModalHeader toggle={this.toggle}>Modal title</ModalHeader>
                            <ModalBody>
                                {user.first_name}{"  "+ user.family_name}
                            </ModalBody>
                            <ModalFooter>
                                <Button color="primary" onClick={this.toggle}>Do Something</Button>{' '}
                                <Button color="secondary" onClick={this.toggle}>Cancel</Button>
                            </ModalFooter>
                        </Modal>
                    </div>
                </div>

            </div>

        )
    }
}

const mapStateToProps = state => ({
    allusers: state.allusers
})
export default connect(mapStateToProps, { fetchAllUsers, getUserViaId })(index);

