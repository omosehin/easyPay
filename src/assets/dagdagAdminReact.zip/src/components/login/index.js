import React, { Component } from "react";
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import classnames from 'classnames';
import { loginUser } from '../../actions/auth';
import {Dagdag} from '../../components/logo/icon'


class index extends Component {
    constructor() {
        super();
        this.state = {
            email: "",
            password: "",
            errors: {},
            submit:false
        };

        this.onChange = this.onChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }

    componentDidMount() {
        if (this.props.auth.isAuthenticated) {
            this.props.history.push('/dashboard');
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.auth.isAuthenticated) {
            this.props.history.push('/dashboard')
        }
        if (nextProps.errors) {
            this.setState({ errors: nextProps.errors,submit:false })
        }
    }

    onSubmit(e) {
        e.preventDefault();
        this.setState({submit:true})
        const userData = {
            email: this.state.email,
            password: this.state.password
        };
        console.log(userData)
        // console.log(user);
        this.props.loginUser(userData);
    }

    onChange(e) {
        this.setState({ [e.target.name]: e.target.value });
    }
    render() {

        const { errors,submit,email,password} = this.state;


        return (
            <div className="login" style={{
                justifyContent: 'center', display: 'flex',
                flexDirection: 'column',
                alignItems: "center",
                textAlign: "center",
                minHeight: "100vh"
            }}>
                <div className="container">
                    <div className="row">
                        <div className="col-md-8 m-auto loginCard">
                            <p className="lead text-center text-white bold" style={{ fontSize: '40px' }}>
                                Sign In
              </p>
                            <form onSubmit={this.onSubmit}>
                                <div className="form-group">
                                    <input
                                        type="email"
                                        required
                                        className={classnames("form-control form-control-lg mt-3 loginFormInput", {
                                            "is-invalid": errors.email
                                        })}
                                        placeholder="Email Address"
                                        name="email"
                                        value={this.state.email}
                                        onChange={this.onChange}
                                    />
                                    {errors.email && (
                                        <div className="invalid-feedback mt-3">{errors.email}</div>
                                    )}
                                </div>
                                <div className="form-group">
                                    <input
                                        type="password"
                                        required
                                        className={classnames("form-control form-control-lg mt-3 loginFormInput", {
                                            "is-invalid": errors.password
                                        })} placeholder="Password"
                                        name="password"
                                        value={this.state.password}
                                        onChange={this.onChange}
                                    />

                                    {errors.password && (
                                        <div className="invalid-feedback mt-3">{errors.password}</div>
                                    )}
                                </div>
                                <input type="submit" className="btn btn-info mt-3 loginButton" value={!submit ? 'Submit' :'Submitting...'} />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


const mapStateToProps = state => ({
    auth: state.auth,
    errors: state.error
})
export default connect(mapStateToProps, { loginUser })(index);

