import React, { Component } from 'react'
import { connect } from 'react-redux'
import MerchantTable from './MerchantTable'
import { Button } from 'reactstrap'
import NewMarchant from './NewMarchant'
import { fetchAllMerchant, addMarchant } from '../../actions/merchant'
class index extends Component {
    state = {
        isNewMarchant: false,
        name:''
    }

    componentDidMount() {
        this.props.fetchAllMerchant();
    }

    gotoAddMerchant =()=>{
         this.setState({ isNewMarchant: true })
         const {history} = this.props
         history.push('/merchants/Addmerchants')
    }
    
    render() {
        const { merchant } = this.props.merchant
        return (
            <div>

                    <div style={{
                        position: 'fixed', zIndex: '100', marginBottom: '300px',
                        background: 'rgb(24, 37, 56)', width: '73.4%', marginTop: '-25px'
                    }}>
                        <h4 style={{ fontSize: '1.5rem', color: '#ffffff' }}>All Merchant <small style={{ fontSize: '14px' }}>List of all merchants</small></h4>

                        <Button color="success"
                            style={{ margin: '10px' }}
                            onClick={this.gotoAddMerchant}>New Merchant</Button>{' '}
                    </div>


                    <MerchantTable merchant={merchant} />
            </div>
        )
    }
}
const mapStateToProps = state => ({
    merchant: state.merchant
})
export default connect(mapStateToProps, { fetchAllMerchant, addMarchant })(index);

