import React, { Component } from 'react'
import {
    Card, CardImg, CardText, CardBody,
    CardTitle, CardSubtitle,
    Form, FormGroup, Label, Input, FormText, Button
} from 'reactstrap';

import { connect } from 'react-redux'
import { addMarchant } from '../../actions/merchant'

// import { ImagePicker } from 'react-file-picker'
import SelectCountry from './SelectCountry'

class NewMarchant extends Component {
    constructor(props) {
        super(props)
        this.state = {
            selectCountry: false,
            name: '',
            file: []
        }

        this.onSubmit = this.onSubmit.bind(this);
    }


    handleChange = (e) => {
        this.setState({ name: e.target.value })
    }

    _onChange = () => {
        // Assuming only image
        var file = this.refs.file.files[0];
        var reader = new FileReader();
        var url = reader.readAsDataURL(file);

        reader.onloadend = (e) => {
            this.setState({ imgSrc: [reader.result] })
        }
        console.log(url)
        // Would see a path?
        // TODO: concat files
    }

    onSubmit() {
     //   e.preventDefault();

        // const { user } = this.props.auth;

        const newMarchant = {
            name: this.state.name,
            // name: user.name,
            // avatar: user.avatar
        };

        this.props.addMarchant(newMarchant);
    //  //   console.log('Name: ')
    //     this.setState({ name: '' });


    }

    render() {
        return (
            <div style={{ height: '100%' }}>
                <h4>Add New Merchant</h4>

                <div style={{ height: '100%' }}>


                    {!(this.state.selectCountry) ? <div>
                        <Card style={{ height: '100%', width: '800px' }}>
                            <CardBody>
                                <Form  onSubmit={this.onSubmit()}>
                                    <FormGroup>
                                        <Label for="exampleEmail">Name</Label>

                                        <Input type="text" name="name"
                                            id="merchantname"
                                            placeholder="Merchant name..."
                                            value={this.state.name}
                                            onChange={this.handleChange} />

                                        <div style={{ margin: '10px' }}>
                                            <input
                                                ref="file"
                                                type="file"
                                                name="user[image]"
                                                onChange={this._onChange} style={{ margin: '10px 0' }} />
                                            <br />
                                            <img src={this.state.imgSrc}
                                                style={{ width: '150px', height: '150px' }} />
                                        </div>


                                    </FormGroup>
                                </Form>
                            </CardBody>
                        </Card>

                        <Button color="success"
                            style={{ margin: '20px 0px' }}
                            disabled={!this.state.name}
                            onClick={() => this.setState({ selectCountry: true })}
                            type="submit">Add Merchant</Button>

                    </div> : <SelectCountry />}



                </div>
            </div>
        )
    }
}

const mapStateToProps = state => ({
    merchant: state.merchant
})
export default connect(mapStateToProps, { addMarchant })(NewMarchant);
