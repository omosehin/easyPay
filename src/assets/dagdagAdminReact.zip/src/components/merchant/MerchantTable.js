import React, { Component } from 'react'
import { Table, Card,CardBody } from 'reactstrap';
import Avatar from '@material-ui/core/Avatar'


export default class MerchantTable extends Component {
  render() {
      const {merchant} = this.props
      console.log('merchant'+JSON.stringify(this.props.merchant))
     return (

        <div>

             <Card style={{ background: 'rgb(24, 37, 56)', padding: '20px', marginTop: '20px' }}>
                 <CardBody style={{ background: 'rgb(24, 37, 56)', marginTop:'100px' }}>
                     <Table responsive>
                         <thead>
                             <tr style={{ color: 'white' }}>
                                 <th>Image</th>
                                 <th>Name</th>
                                 <th>Type</th>
                                 <th>Rate</th>
                                 <th>Actions</th>
                             </tr>
                         </thead>
                         <tbody style={{ color: '#6c757d' }}>

                             {
                                 merchant.map((trans) => {
                                     return (
                                         <tr >
                                             <td style={{}}><img src={'/'+trans.image} style={{width:'100px', height:'100px'}}/></td>
                                             <td>{trans.name}</td>
                                             <td>{trans.country.length > 0 ? <p>bank</p> : <p>N/A</p>}</td>
                                             <td>{} </td>
                                             <td>...</td>
                                         </tr>
                                     )

                                 })
                             }

                         </tbody>
                     </Table>
                 </CardBody>
             </Card> 
        </div>
           
        );
  }
}
