import  React from "react";
import { Link } from 'react-router-dom';
import dagdag from '.../../../public/image/dagdag.svg'
import Avatar from '@material-ui/core/Avatar';


export const Dagdag = (props) => {

    const template = <div>
        <Avatar alt="Remy Sharp" class="" src={dagdag} style={{width:'150px', height:'98%', marginLeft:'50px'}} />

    </div>

    if (props.link) {
        return (
            <Link to={props.linkTo} className="link_logo">
                {template}
            </Link>
        )
    } else {
        return template
    }
}
