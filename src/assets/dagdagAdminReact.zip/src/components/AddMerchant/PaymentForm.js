import React,{Component} from 'react';
import Typography from '@material-ui/core/Typography';
import {countries} from './Country'
import Select from 'react-select'
import Button from '@material-ui/core/Button';

const style={
  marginTop:'20px'
}
class PaymentForm extends Component {
    constructor(props){
      super(props)
      this.state={
          country:[],
          selectedCounttry:{},
          hasError:false
      }
    }
    handleSubmit=(e)=>{
      e.preventDefault()
        console.log(this.state.selectedCounttry.value) 
      }
    
    handleSelect(option){
      this.setState({
        selectedCounttry:option
      })
    }
  render(){
    const {noError} = this.props 
    let Selected_Country =countries.map((country)=>{
      return{label:country,value:country}
    })

  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Payment method
      </Typography>
      <form onSubmit = {this.handleSubmit}>
      <Select
         placeholder='Select Country'
          onChange={this.handleSelect.bind(this)}
          options={Selected_Country} />
          <Button
                    style={style}
                    type='submit'
                    variant="contained"
                    color="primary"
                    noError={noError} onClick={this.handleSubmit}
                  >
                    Submit
                  </Button>
      </form>
    </React.Fragment>
  );
}
}

export default PaymentForm