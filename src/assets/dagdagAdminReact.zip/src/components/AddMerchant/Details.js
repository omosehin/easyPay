import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import ImageUploader from 'react-images-upload';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import Select from 'react-select'
import {countries,channel} from './Country';
const fileContainerStyle = {
        width: '93%'
}
const style={
    marginTop:'20px'
}

class Details extends Component{
    constructor(props) {
        super(props);
        this.state = {
            selectedCounttry:{},
            selectedChannel:{},
            details:{
                channel:'',
                currency:'',
                Rate:'',
                commission:''
            }
      }
    }

  
    handleSubmit = (e) =>{
        const {details} = this.state
        e.preventDefault()
        const selectedCountry =this.state.selectedCounttry.value
        const selectedChannel =this.state.selectedChannel.value
        const data ={...details,currency:selectedChannel,channel:selectedCountry}
        console.log(data)
    }

    handleChange = (e)=>{
        const{details} = this.state
        details[e.target.name]=e.target.value
        this.setState({details})
    }
    handleSelect(option){
        this.setState({
          selectedCounttry:option,
          selectedChannel:option
        })
      }
    
render(){
    const{details} = this.state
    let Selected_Country =countries.map((country)=>{
        return{label:country,value:country}
      })

    let Selected_channel =channel.map((channel)=>{
        return{label:channel,value:channel}
      })
    return (
        <React.Fragment>
          <Typography variant="h6" gutterBottom>
            Payment Details
          </Typography>
          <form onSubmit ={this.handleSubmit}>
              <Select
         placeholder='Select Channel'
          onChange={this.handleSelect.bind(this)}
          options={Selected_channel} />
        <Select
            placeholder='Select Country'
            onChange={this.handleSelect.bind(this)}
            options={Selected_Country} 
            className ='Selectcountry'
            />
              
             
                <TextField
                id="Rate"
                name="Rate"
                value={details.Rate}
                label="Exchange Rate"
                onChange={this.handleChange}
                fullWidth
                autoComplete="name"
              /> 
                <TextField
                id="commission"
                name="commission"
                value={details.commission}
                label="Commission"
                onChange={this.handleChange}
                fullWidth
                autoComplete="name"
              /> 
           
            <Button
                    type='submit'
                    variant="contained"
                    color="primary"
                    style={style}
                  >
                    Submit
                  </Button>

             </form>
        </React.Fragment>
      );
}
 
}
export default Details