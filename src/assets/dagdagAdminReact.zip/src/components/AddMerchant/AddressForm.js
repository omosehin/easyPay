import React, { Component } from 'react';
import {connect} from 'react-redux';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import ImageUploader from 'react-images-upload';
import Button from '@material-ui/core/Button';
import {merchantData} from '../../actions/payment'


class MerchantInit extends Component{
    constructor(props) {
        super(props);
        this.state = {
            pictures: [],
            Merchant: '',
      }
    }

    handleSubmit = (e) =>{
        e.preventDefault()        
        let data =this.state
        let sub = {...data,name:data.Merchant}
         this.props.merchantDataFn(sub.name)
        
    }

    handleChange = (e)=>{
        this.setState({Merchant:e.target.value})
    }
    onDrop =(picture)=>{
        this.setState({
            pictures: this.state.pictures.concat(picture),
        });
    }
render(){
    const{Merchant,pictures} = this.state

    return (
        <React.Fragment>
          <Typography variant="h6" gutterBottom>
            Merchant address
          </Typography>
          <form onSubmit={this.handleSubmit}>
                <TextField
                id="Merchant"
                name="Merchant"
                value={Merchant}
                label="Merchant name"
                onChange={this.handleChange}
                fullWidth
                autoComplete="name"
              /> 
            <ImageUploader
                withPreview={true}
                withIcon={false}
                buttonText='Choose images'
                onChange={this.onDrop}
                imgExtension={['.jpg', '.gif', '.png', '.gif']}
                maxFileSize={5242880}
                value={pictures}
            />
            <Button
                    type='submit'
                    variant="contained"
                    color="primary"
                  >
                    Submit
                  </Button>
             </form>
        </React.Fragment>
      );
}
 
}
const mapStateToProps =(state)=>{
return{
  paymentIni:state.PaymentInitReducer.data,
  paymentIniStarting:state.PaymentInitReducer.merchantInitIdentityPayment
}
}
const mapDispatchToProps =dispatch=>{
  return{
    merchantDataFn:data=>{dispatch(merchantData(data))}
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(MerchantInit)