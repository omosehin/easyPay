import React from 'react';
import {connect} from 'react-redux'
import {
    Card, Button, CardImg, CardTitle, CardText, CardColumns,
    CardSubtitle, CardBody
} from 'reactstrap';
import TransactionTable from './TransactionTable'

const CardGrid = (props) => {
console.log(props.transactions)
    return (
        <div style={{}}>
            <CardColumns>
                <Card body inverse style={{ backgroundColor: '#00337E', borderColor: '#333', height: '180px' }}>
                        <div style={{ marginTop: '38px' }} className =' d-flex flex-column justify-content-center text-center'>
                            <h6>Total Month Transactions in {props.month}</h6>
                            <p><strong>250,000</strong></p>
                        </div>
                </Card>

                <Card body inverse style={{ backgroundColor: '#424F59', borderColor: '#333', height: '180px' }}>
                        <div style={{ marginTop: '38px' }}  className =' d-flex flex-column justify-content-center text-center'>
                            <h6>Total Sent</h6>
                            <p><strong>80,000</strong></p>
                        </div>
                </Card>

                {props.totaluser === undefined ? <Card body inverse style={{ backgroundColor: '#FB7D64', borderColor: '#333', height: '180px' }}>

                        <div style={{ marginTop: '38px' }} >
                            <h6 style={{ fontSize: '1rem' }}>Total Users</h6>
                            <p style={{ fontSize: '30px', fontWeight: '800px' }}>0<strong></strong></p>
                        </div>
                </Card> : <Card body inverse style={{ backgroundColor: '#FB7D64', borderColor: '#333', height: '180px' }}>

                            <div style={{ marginTop: '38px' }}  className =' d-flex flex-column justify-content-center text-center'>
                                <h6 >Total Users</h6>
                                <p><strong>{props.totaluser}</strong></p>
                            </div>
                    </Card>}


            </CardColumns>
        </div>
    );
};


export default CardGrid;