import React from 'react';
import { Table } from 'reactstrap';
import moment from 'moment'

const TransactionTable = (props) => {
    {
        const { lastThreeTranzact} = props       
        return(
            <div>
                {!props.lastThreeTranzact.length > 0 ? <p style={{color:'white'}}>No transactions {props.lastThreeTranzact._id}</p> :
                    <Table  style={{ margin: '10px', padding: '20px', background: 'rgb(24, 37, 56)' }}>
                        <thead style={{ color: 'white' }}>
                            <tr>
                                <th>Amount</th>
                                <th>Destination Rate</th>
                                <th>Customer</th>
                                <th>Country to</th>
                                <th>Date</th>

                            </tr>
                        </thead>
                        <tbody style={{ color: '#6c757d' }}>


                                {
                                    lastThreeTranzact.map((trans) => {
                                        return (
                                            <tr >
                                                <td>{trans.amount}</td>
                                                <td>{trans.destination_exchange_rate}</td>
                                                <td>{trans.user.first_name} {trans.user.family_name}</td>
                                                <td>{trans.country_to} </td>
                                                <td>{moment(trans.date_created).format('dddd, MMMM Do YYYY, h:mm:ss a')}</td>
                                            </tr>
                                        )

                                    })
                                }


                        </tbody>
                    </Table>}
            </div>
            


        );
       }
    
}
export default TransactionTable;