import React, { Component } from 'react'
import {connect} from 'react-redux';
import { getLastThreeTransactions,getMonthName,getAllUsers} from '../../actions/dashboard'

import CardGrid from './CardGrid';
import TransactionTable from './TransactionTable'

class index extends Component {

    componentDidMount(){
        this.props.getLastThreeTransactions();
        this.props.getMonthName();
        this.props.getAllUsers();
    }
    render() {
        const { lastThreeTranzact, totalUser, month} = this.props.dashboard
        return (
            <div>
                <h4 style={{ fontSize: '1.5rem',color:'#ffffff',height:'100%'}}>Dashboard <small style={{fontSize:'14px'}}>statistics, charts many more</small></h4>
                <p style={{color:'#ffffff'}}>Home / Dashboard</p>
                <CardGrid month={month} totaluser={totalUser}/>
                <TransactionTable lastThreeTranzact={lastThreeTranzact} />

            </div>
        )
    }
}

const mapStateToProps =state =>({
    dashboard: state.dashboard,
});

export default connect(mapStateToProps, { getLastThreeTransactions, getMonthName, getAllUsers})(index);
