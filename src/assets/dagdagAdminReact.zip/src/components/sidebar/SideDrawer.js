import React,{Component} from 'react';
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import CssBaseline from '@material-ui/core/CssBaseline';
import Divider from '@material-ui/core/Divider';
import Drawer from '@material-ui/core/Drawer';
import Hidden from '@material-ui/core/Hidden';
import IconButton from '@material-ui/core/IconButton';
import InboxIcon from '@material-ui/icons/MoveToInbox';
import Bag from '@material-ui/icons/CardTravel';
import Home from '@material-ui/icons/HomeOutlined';
import Account from '@material-ui/icons/AccountBalance';
import Payment from '@material-ui/icons/Payment';
import List from '@material-ui/core/List';

import MailIcon from '@material-ui/icons/Mail';
import MenuIcon from '@material-ui/icons/Menu';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import CardGrid from '../Home/CardGrid'
import { NavLink, NavNavLink } from "react-router-dom";
import Avatar from '@material-ui/core/Avatar';
import angleLeft from '.../../../public/image/angle-left.svg'
import homeIcon from '.../../../public/image/home.svg'
import bag from '.../../../public/image/bag.svg'
import packag from '.../../../public/image/package.svg'
import creditcard from '.../../../public/image/credit-card.svg'
import email from '.../../../public/image/email.svg'
import user from '.../../../public/image/user.svg'
import bell from '.../../../public/image/bell.svg'
import poweroff from '.../../../public/image/power-off.svg'
import merchant from '.../../../public/image/merchant.svg'

const useStyles = makeStyles({
  avatar: {
    margin: 10,
  },
  bigAvatar: {
    margin: 10,
    width: 60,
    height: 60,
  },
});



class SideDrawer extends Component{

  render(){
    return (
      <div style={{ width: '220px', marginTop: '100px', marginLeft: '10px' ,background:'#182538',position:'fixed'}}>
        <div className="sidebar-menu">
          <ul id="nav-accordion" style={{ listStyle: "none" }} >
            <li className="sub-menu" style={{ position: 'relative', margin: '0 15px', lineHeight: '15px', color: 'white'}} >
              <NavLink to="/dashboard"  activeStyle={{ borderBottom: 'solid 3px #FB7D64', background:'none', paddingBottom: '1em'}}
              activeClassName="selected" style={{ textDecoration: "none", color: 'white', fontWeight:'400'}}>
                <div style={{ margin: '5px' }}>  <img src={homeIcon} style={{fill:'#ffffff'}} />
                <span style={{marginLeft:'7px', alignItem:'center'}}>Dashboard</span>
                 </div> 
               
              </NavLink>
  
            </li>
  
  
            <li className="sub-menu" style={{ position: 'relative', margin: '0 15px', lineHeight: '15px' }} >
              <NavLink to="/all-users" activeStyle={{ borderBottom: 'solid 3px #FB7D64', background: 'none', paddingBottom: '1em' }}>
                <div style={{ margin: '5px' }}>  <img src={bag} />
                  <span style={{ marginLeft: '7px', alignItem: 'center' }}>All users</span>
                </div>
  
              </NavLink>
  
            </li>
            
  
  
              <li className="sub-menu" style={{ position: 'relative', margin: '0 15px', lineHeight: '15px' }} >
              <NavLink to="/transactions" activeStyle={{ borderBottom: 'solid 3px #FB7D64', background: 'none', paddingBottom: '1em' }}>
                  <div style={{ margin: '5px' }}>  <img src={packag} />
                    <span style={{ marginLeft: '7px', alignItem: 'center' }}>Transactions</span>
                  </div>
  
                </NavLink>
  
              </li>
  
  
  
           
  
            <li className="sub-menu" style={{ position: 'relative', margin: '0 15px', lineHeight: '15px' }} >
              <NavLink to="/reconcile-payment" activeStyle={{ borderBottom: 'solid 3px #FB7D64', background: 'none', paddingBottom: '1em' }}>
                <div style={{ margin: '5px' }}>  <img src={creditcard} />
                  <span style={{ marginLeft: '7px', alignItem: 'center' }}>Reconsile Payment</span>
                </div>
              </NavLink>
            </li>
  
           
  
            <li className="sub-menu" style={{ position: 'relative', margin: '0 15px', lineHeight: '15px' }} >
              <NavLink to="/merchants" activeStyle={{ borderBottom: 'solid 3px #FB7D64', background: 'none', paddingBottom: '1em' }}>
                <div style={{ margin: '5px' }}>  <img src={merchant}  style={{width:'20px', height:'20px'}}/>
                  <span style={{ marginLeft: '7px', alignItem: 'center' }}>Merchant</span>
                </div>
              </NavLink>
            </li>
  
  
            <li className="sub-menu" style={{ position: 'relative', margin: '0 15px', lineHeight: '15px' }} >
              <NavLink to="/send-mail" activeStyle={{ borderBottom: 'solid 3px #FB7D64', background: 'none', paddingBottom: '1em' }}>
                <div style={{ margin: '5px' }}>  <img src={email} />
                  <span style={{ marginLeft: '7px', alignItem: 'center' }}>Send Mail</span>
                </div>
              </NavLink>
            </li>
  
  
            <li className="sub-menu" style={{ position: 'relative', margin: '0 15px', lineHeight: '15px' }} >
              <NavLink to="/admin-users" activeStyle={{ borderBottom: 'solid 3px #FB7D64', background:'none', paddingBottom: '1em'}}>
                <div style={{ margin: '5px' }}>  <img src={user} />
                  <span style={{ marginLeft: '7px', alignItem: 'center' }}>Admin Users</span>
                </div>
              </NavLink>
            </li>
  
          
  
            <li className="sub-menu" style={{ position: 'relative', margin: '0 15px', lineHeight: '15px' }} >
              <NavLink to="/app-notification" activeStyle={{ borderBottom: 'solid 3px #FB7D64', background: 'none', paddingBottom: '1em' }}>
                <div style={{ margin: '5px' }}>  <img src={bell} />
                  <span style={{ marginLeft: '7px', alignItem: 'center' }}>App Notification</span>
                </div>
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    )
}
}

export default SideDrawer;