import React from 'react';
import { Table } from 'reactstrap';

export default class Transactions extends React.Component {
    render() {
        const {allTransactions} = this.props.transactions

        // console.log('??????????????????????????' + JSON.stringify(this.props.transactions))
        console.log('??????????????????????????' + JSON.stringify(this.props.transactions.amount))
        return (
            <Table responsive>
                <thead>
                    <tr style={{ color: 'white' }}>
                        <th>#</th>
                        <th>Amount</th>
                        <th>Rate</th>
                        <th>Customer</th>
                        <th>Country</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody style={{ color: '#6c757d' }}>
                     {
                        // this.props.transactions.map((trans) => {
                            // return (
                                <tr >
                                    <th scope="row">1</th>
                                    <td>{}</td>
                                    <td>Table cell</td>
                                    <td>Table cell</td>
                                    <td>Table cell</td>
                                    <td>Table cell</td>
                                </tr>
                            // )

                        // })
                    } 
                   
                   
                </tbody>
            </Table>
        );
    }
}