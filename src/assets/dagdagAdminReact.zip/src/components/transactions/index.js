import React, { Component } from 'react'
import Transactions from './Transactions'
import { connect } from 'react-redux';
import {
  Card, Button, CardImg, CardTitle, CardText, CardColumns,
  CardSubtitle, CardBody,Table
} from 'reactstrap';
import {fetchAllTransactions} from '../../actions/transactions'

 class index extends Component {

  componentDidMount(){
    this.props.fetchAllTransactions();
  }
  render() {
   const { transactions} = this.props.transactions
    console.log('tranda---: ' + JSON.stringify(transactions))
    return (
      <div>

        <h4 style={{ fontSize: '1.5rem', color: '#ffffff' }}>All transactions <small style={{ fontSize: '14px' }}>list of user Transactions</small></h4>
      
        <Card style={{ background: 'rgb(24, 37, 56)', padding: '20px', marginTop: '20px' }}>
          <CardBody style={{ background: 'rgb(24, 37, 56)' }}>
            <Table responsive>
              <thead>
                <tr style={{ color: 'white' }}>
                  <th>Amount</th>
                  <th>Rate</th>
                  <th>Customer</th>
                  <th>Country</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody style={{ color: '#6c757d' }}>
               
                {
                transactions.map((trans) => {
                    return (
                      <tr >
                        <td>{trans.amount}</td>
                        <td>{trans.rate}</td>
                        <td>{trans.user.first_name} {trans.user.family_name} </td>
                        <td>Table cell</td>
                        <td>Table cell</td>
                      </tr>
                    )

                  })
                }

              </tbody>
            </Table>
          </CardBody>
        </Card>
        
      </div>
    )
  }
}
const mapStateToProps = state => ({
  transactions: state.transactions
})
export default connect(mapStateToProps, { fetchAllTransactions })(index);

