// import React from 'react';
// import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
// import CardGrid from '../src/components/Home'
// import AllUsers from '../src/components/all-users/AllUsers'
// import Transactions from '../src/components/transactions'
// import ReconsilePayment from '../src/components/reconsilepayment'
// import Merchant from '../src/components/merchant'
// import SendMail from '../src/components/sendmaill'
// import Admin from '../src/components/admin'
// import 'bootstrap/dist/css/bootstrap.css';
// import { Table } from 'reactstrap';
// import Layout from '../src/Hoc/Layout'
import Navbar from './Hoc/Navbar'
// import Routes from './Routes'


import React from 'react'
import Layout from './Hoc/Layout'
import jwt_decode from 'jwt-decode'
import setAuthToken from './util/setAuthToken'
import { setCurrentUser } from './actions/auth'
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { Provider } from 'react-redux';
import store from './store'
// import SideDrawer from './components/sidebar/SideDrawer'

import CardGrid from '../src/components/Home'
import AllUsers from './components/all-users'
import Transactions from '../src/components/transactions'
import ReconsilePayment from '../src/components/reconsilepayment'
import Merchant from '../src/components/merchant'
import SendMail from '../src/components/sendmaill'
import Admin from '../src/components/admin'
import Login from './components/login'
import Header from './components/headerandfooter/Header'
import { Row, Col } from 'reactstrap';
import PrivateRoute from './util/PrivateRoute'
import SideDrawer from './components/sidebar/SideDrawer'
import CheckOut from './components/AddMerchant/CheckOut';

function App() {
  return (
    <div className="App">

      <Provider store={store}>
        <Router>
          <Header />
          <Route path="/login" component={Login} />


          {/* <Layout> */}
          <Row style={{ background: '#141e2f', marginTop:'' }} >

              <Col xs='3'>
                <SideDrawer />
              </Col>

              <Col xs='9' style={{ marginTop: '100px', marginLeft: '-100px' }}>
                <PrivateRoute exact path="/" component={CardGrid} />
                <PrivateRoute path="/dashboard" component={CardGrid} />
                <PrivateRoute path="/all-users" component={AllUsers} />
                <PrivateRoute path="/transactions" component={Transactions} />
                <PrivateRoute path="/reconcile-payment" component={ReconsilePayment} />
                <PrivateRoute exact path="/merchants" component={Merchant} />
                <PrivateRoute path="/merchants/Addmerchants" component={CheckOut} />
                <PrivateRoute path="/send-email" component={SendMail} />
                <PrivateRoute path="/admin-users" component={Admin} />
              </Col>
          </Row>



          {/* </Layout> */}
        </Router>
      </Provider>



    </div>
  );
}

export default App;



